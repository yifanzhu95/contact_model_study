this one used Mujcoco as the eval simulator and it used these as the params
N_SAMPLES=256
HORIZON=48
TEMPERATURE=25.0
NOISE_SIGMA=0.01
DELTA=0.1
EVAL_SIM="mujoco"                 # "none" uses the task default; "mujoco" is faster
SETTLE=1.0
GEOMETRY="accurate"
SEED=0

the temp was adjusted unlike the last one. 
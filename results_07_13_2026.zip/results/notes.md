Im pretty sure that the temp was set way to low for most of the expeirments done here.

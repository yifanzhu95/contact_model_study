top few lines from the param search:

w_quat	w_pos_x	w_pos_y	w_pos_z	w_contact	w_joint	success_rate_M2	success_rate_M3	mean_success_rate	mean_step_ms_M2	mean_step_ms_M3	mean_step_ms_avg	mean_steps_to_success_M2	mean_steps_to_success_M3	n_episodes
5.0	7.5	30.0	7.5	5.0	0.6	0.2000	1.0000	0.6000	40.981	25.358	33.170	867.0	636.2	5
10.0	3.75	15.0	3.75	5.0	0.6	0.2000	1.0000	0.6000	40.595	25.773	33.184	996.0	465.4	5
20.0	7.5	7.5	7.5	5.0	0.6	0.2000	1.0000	0.6000	42.465	25.492	33.979	736.0	460.4	5
10.0	7.5	7.5	3.75	5.0	0.6	0.0000	1.0000	0.5000	40.383	25.544	32.964		649.8	5


Shows a strong prefrance for Comfree im gonna choose the 2nd line as it seems the most likely that M2 was simply timing out. Im going to do another search involving the contact weights and the joint weights. still just M2 and M3
going to increase the number of steps tho.

w_quat	w_pos_x	w_pos_y	w_pos_z	w_contact	w_joint	success_rate_M2	success_rate_M3	mean_success_rate	mean_step_ms_M2	mean_step_ms_M3	mean_step_ms_avg	mean_steps_to_success_M2	mean_steps_to_success_M3	n_episodes
10.0	3.75	15.0	3.75	10.0	0.3	0.6000	1.0000	0.8000	40.669	26.296	33.482	1915.7	725.8	5
10.0	3.75	15.0	3.75	5.0	0.6	0.6000	1.0000	0.8000	42.131	26.692	34.412	2635.7	527.2	5
10.0	3.75	15.0	3.75	5.0	1.2	0.4000	1.0000	0.7000	40.534	25.319	32.927	2290.0	642.2	5

gonna choose the 1st one much better sucess across the board. decent balance of times and things
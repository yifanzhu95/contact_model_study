there were some big changes between the param search and the evals.

paramsearch used different backend models


MODELS=("M1" "M2" "M3" "M4")
W_QUAT=("100" "75" "50")
W_POS=("500" "400" "300")
W_CONTACT=("1000" "750" "500")
W_JOINT=("8" "6" "4")

# Shared MPPI / eval knobs (single values, not swept).
N_SAMPLES=256
HORIZON=8
TEMPERATURE=10.0
NOISE_SIGMA=0.01
DELTA=0.1
SUBSTEPS=8 <- actuall idk
EVAL_SIM="none" #"none"
SETTLE=1.0
GEOMETRY="accurate"
SEED=0


other params 

MODELS=("M1" "M2" "M3" "M4")
SUBSTEPS_SWEEP=("2" "4" "8" "16" "32" "64")   # the swept substep counts

# Shared MPPI / eval knobs (single values, not swept).
N_SAMPLES=256
HORIZON=8
TEMPERATURE=0.50
NOISE_SIGMA=0.01
DELTA=0.1
EVAL_SIM="none"                 # "none" uses the task default; "mujoco" is faster
SETTLE=1.0
GEOMETRY="accurate"
SEED=0
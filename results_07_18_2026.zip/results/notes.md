Param search params:

TASK="grasp_reorient"
N_EPISODES=5          # episodes per weight set -> success rate

MODELS=("M1" "M2" "M3" "M4")
W_QUAT=("10.0" "5.0" "2.5")
W_POS=("80" "40" "20")
W_CONTACT=("5" "2.5" "1.25")
W_JOINT=("0.2" "0.1" "0.05")

N_SAMPLES=256
HORIZON=8
TEMPERATURE=0.01
NOISE_SIGMA=0.02
DELTA=0.1
SUBSTEPS=8
EVAL_SIM="none" #"none"
SETTLE=1.0
GEOMETRY="accurate"
SEED=0


I chose 3rd row down in the param search resutls.
This row seem to balance success between all four models.

which gives these weights
cost_weights       = {
                "w_quat": 10.0, #5.0
                "w_pos": 20.0, #40.0
                "w_velo": 0.0,
                "w_contact": 1.25,#250.0,#500.0,#2.5
                "w_joint": 0.10, #0.1
                "w_joint_velo": 0.0,
                "w_fallen": 30.0, #30.0,
                "w_quat_term": 10.0, #10.0
                "w_pos_term": 10.0, #10.0
                "w_fallen_term": 0.0,
            },

Rollouts params:
TASK="grasp_reorient"
N_EPISODES=10                                    # episodes per (model, n_samples) cell

MODELS=("M1" "M2" "M3" "M4")
N_SAMPLES=("16" "64" "256" "1024" "4096")    # the swept rollout counts

# Shared MPPI / eval knobs (single values, not swept).
HORIZON=8
TEMPERATURE=0.01
NOISE_SIGMA=0.02
DELTA=0.1
SUBSTEPS=8
EVAL_SIM="none"                 # "none" uses the task default; "mujoco" is faster
SETTLE=1.0
GEOMETRY="accurate"
SEED=0

Horizon Params:

TASK="grasp_reorient"
N_EPISODES=10                                # episodes per (model, horizon) cell

MODELS=("M1" "M2" "M3" "M4")
HORIZONS=("2" "4" "8" "16" "32")            # the swept planning horizons

# Shared MPPI / eval knobs (single values, not swept).
N_SAMPLES=256
TEMPERATURE=0.01
NOISE_SIGMA=0.02
DELTA=0.1
SUBSTEPS=8
EVAL_SIM="none"                 # "none" uses the task default; "mujoco" is faster
SETTLE=1.0
GEOMETRY="accurate"
SEED=0

Cntrl Freq:
TASK="grasp_reorient"
N_EPISODES=10                                   # episodes per (model, substeps) cell

MODELS=("M1" "M2" "M3" "M4")
SUBSTEPS_SWEEP=("2" "4" "8" "16" "32")   # the swept substep counts

# Shared MPPI / eval knobs (single values, not swept).
N_SAMPLES=256
HORIZON=8
TEMPERATURE=0.01
NOISE_SIGMA=0.02
DELTA=0.1
EVAL_SIM="none"                 # "none" uses the task default; "mujoco" is faster
SETTLE=1.0
GEOMETRY="accurate"
SEED=0

a lot of things are changing with this one,
there is now a difference between the eval model and rollout model geometries, mostly the yokes and stuff were added to the eval geom.
there is also chagnes to how horizon and stuff are defined. moved to explicet time based deffintion. 
also increasing the diffulty

Nominal Params:
N_SAMPLES=256
TIME_HORIZON=0.256              # planning horizon in seconds
STEP_TIME=0.032                 # control-step duration in seconds
TEMPERATURE=0.01
NOISE_SIGMA=0.02
DELTA=0.1
EVAL_SIM="none" #"none"
SETTLE=1.0
GEOMETRY="accurate"
SEED=0

Weights:

max_steps = 4000,
success_thresholds = {"pos": 0.02, "quat": 0.04, "vel": 0.1},
cost_weights = {
"w_quat": 10.0,#100.0,
"w_pos_x": 7.50,#60.0,   #I think X is down the fingers # separate X/Y/Z position-error weights
"w_pos_y": 15.0,#80.0,    #Y is across the fingers
"w_pos_z": 15.0,#15.0,
"w_velo": 0.0,
"w_contact": 12.50,
"w_joint": 0.60,
"w_joint_velo": 0.0,
"w_fallen": 200.0,
"w_quat_term": 100.0,
"w_pos_term": 200.0,
"w_fallen_term": 0.0,
},
ran the code with warm starts on. that resulted in the first set of experiments. doing a second set with warm start off.

did no param search since it started with a wieghts that seemed to do pretty well across the board

the 2nd cntrl freq experiment didnt have the warms start turned off. but it is now!

Nominal Params:
N_SAMPLES=256
HORIZON=8
TEMPERATURE=0.01
NOISE_SIGMA=0.02
DELTA=0.1
SUBSTEPS=8
EVAL_SIM="none"
SETTLE=1.0
GEOMETRY="accurate"
SEED=0

Weights:

max_steps = 2000,
success_thresholds = {"pos": 0.02, "quat": 0.04, "vel": 0.1},
cost_weights = {
"w_quat": 10.0,#100.0,
"w_pos_x": 7.50,#60.0,   #I think X is down the fingers # separate X/Y/Z position-error weights
"w_pos_y": 15.0,#80.0,    #Y is across the fingers
"w_pos_z": 15.0,#15.0,
"w_velo": 0.0,
"w_contact": 12.50,
"w_joint": 0.60,
"w_joint_velo": 0.0,
"w_fallen": 200.0,
"w_quat_term": 100.0,
"w_pos_term": 200.0,
"w_fallen_term": 0.0,
},